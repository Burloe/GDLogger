@tool
extends EditorPlugin

var dock
var gdl_ico_darkmode = preload("uid://vlt2sbet5kyx")
var gdl_ico_lightmode = preload("uid://defy21wg6ksuo")

func _enter_tree() -> void:
	dock = preload("uid://0k0tpsfqof2s").instantiate() as EditorDock
	dock.title = "GDLogger"
	add_dock(dock)
	dock.plugin_version = get_plugin_version()
	dock.renable_btn.button_up.connect(_renable_plugin) 
	dock.dock_reload_btn.button_up.connect(_renable_plugin)



func _exit_tree() -> void: 
	remove_dock(dock)
	dock.queue_free()
	dock = null



func _enable_plugin() -> void:
	if !Engine.has_singleton("Log"):
		add_autoload_singleton("Log", "res://addons/gdlogger/scenes/log.tscn")



func _disable_plugin() -> void:
	if Engine.has_singleton("Log"):
		remove_autoload_singleton("Log")



func _renable_plugin() -> void:
	if Input.is_key_pressed(KEY_CTRL):
		_exit_tree()
		_enter_tree()
		print_rich("GDLogger: Reload complete. Good job finding this ദ്ദി(ᵔᗜᵔ)")