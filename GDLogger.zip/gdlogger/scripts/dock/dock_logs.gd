@tool
extends HBoxContainer

signal request_categories_save

@onready var add_category_btn: Button = %AddCategoryButton
@onready var category_scroll_container: ScrollContainer = %CategoryScrollContainer
@onready var category_container: GridContainer = %CategoryGridContainer

@onready var prompt_popup: PanelContainer = %PromptPopupPanelContainer
@onready var reload_dock_btn: Button = %ReloadDockButton
@onready var del_cat_popup: MarginContainer = %DeleteCategoryPopup
@onready var cancel_del_cat_btn: Button = %CancelButton
@onready var keep_dir_yes_btn: Button = %KeepDirYesButton
@onready var keep_dir_no_btn: Button = %KeepDirNoButton

@onready var polling_timer: Timer = %PollingTimer
@onready var popup_panel: PopupPanel = %LogFilePanelPopup

@onready var log_settings_btn: Button = %LogSettingsButton
@onready var log_settings_popup: PopupPanel = %LogsSettingsPanelPopup
@onready var open_w_os_btn: CheckButton = %LGOpenLogsCheckButton
@onready var colorcode_btn: CheckButton = %LGColorCodeCheckButton
@onready var sort_mode_btn: Button = %LGSortButton
@onready var auto_reload_btn: CheckButton = %LGAutoReloadCheckButton
@onready var poll_rate_container: BoxContainer = %PollRateBoxContainer
@onready var poll_rate_lbl: Label = %PollRateLabel
@onready var poll_rate_slider: HSlider = %PollRateHSlider

@onready var file_container: FlowContainer = %FileFlowContainer 
@onready var reload_btn: Button = %LGReloadButton

@onready var settings = EditorInterface.get_editor_settings()
@export var data: GDLData = null
var inspector: EditorInspector

const LOG_FILE_BUTTON := preload("uid://bq7nahsc5aca7")
const CATEGORY_SCENE = preload("uid://c3n416c5fajm5")
const HUE_STEP := 0.618034 # Golden ratio conjugate: consecutive hues stay well separated.
const LOGFILE_COLOR_ITEMS: Array[String] = ["font_color", "font_hover_color", "font_hover_pressed_color"]

var is_active: bool = true
var is_shutting_down: bool = false
var is_reloading: bool = false
var _default_setting_in_progress: bool = false

var base_dir = ""
var hovered_logfile: GDLLogFile
var log_files: Array[GDLLogFile] = []
var category_to_delete: GDLLogCategory = null
var current_category: String = "":
	set(value):
		if value != current_category:
			current_category = value 
			load_log_files()

var open_log_with_os: bool = false:
	set(value):
		open_log_with_os = value
		open_w_os_btn.text = "Open files externally" if value else "Open files in Editor"
		data.open_logs_enternally = value

var cur_sort: int = 0: 
	set(value):
		cur_sort = value
		var modes := ["New first ", "Old first "]
		data.browser_sort = value
		sort_mode_btn.text = modes[value]

var reload_automatically: bool = true:
	set(value):
		reload_automatically = value
		data.auto_reload = value
		reload_btn.visible = !value

var poll_rate_value: int = 1:
	set(value):
		poll_rate_value = value
		data.poll_rate = value
		poll_rate_lbl.text = str("Poll Rate\n", data.poll_rate, " sec")
		polling_timer.stop()
		polling_timer.wait_time = value
		polling_timer.start(value)





func _ready() -> void:
	log_settings_popup.hide()
	_connect_unique(add_category_btn.button_up, _add_category)  
	cancel_del_cat_btn.button_up.connect(_on_del_prompt_button_up.bind(cancel_del_cat_btn))
	keep_dir_yes_btn.button_up.connect(_on_del_prompt_button_up.bind(keep_dir_yes_btn))
	keep_dir_no_btn.button_up.connect(_on_del_prompt_button_up.bind(keep_dir_no_btn))
	reload_btn.button_up.connect(load_log_files)
	polling_timer.timeout.connect(func() -> void: if reload_automatically: load_log_files())
	log_settings_btn.button_up.connect(_on_log_settings_button_up)
	auto_reload_btn.toggled.connect(
		func(toggled_on: bool) -> void: 
			reload_automatically = toggled_on
			poll_rate_container.modulate = Color.WHITE if toggled_on else Color("ffffff46")
			if toggled_on:
				polling_timer.stop()
				polling_timer.wait_time = data.poll_rate
				polling_timer.start(data.poll_rate)
			else:	polling_timer.stop()
	)
	poll_rate_slider.drag_ended.connect(func(toggled_on: bool) -> void: poll_rate_value = poll_rate_slider.value)
	open_w_os_btn.toggled.connect(func(toggled_on: bool) -> void: open_log_with_os = toggled_on)
	colorcode_btn.toggled.connect(_on_colorcode_changed)
	sort_mode_btn.button_up.connect(
		func() -> void:
			cur_sort = (cur_sort + 1) % 2
			load_log_files()
	) 
	open_log_with_os = open_log_with_os # Loads the icon from setter



#region Categories

func initialize_tab() -> void:
	reload_automatically = data.auto_reload
	reload_btn.visible = !data.auto_reload
	
	cur_sort = data.browser_sort
	colorcode_btn.button_pressed = data.colorcode_dates
	reload_automatically = data.auto_reload
	auto_reload_btn.button_pressed = data.auto_reload
	poll_rate_value = data.poll_rate
	poll_rate_container.modulate = Color.WHITE if data.auto_reload else Color("ffffff46")



	for log_c in category_container.get_children():
		log_c.queue_free()

	ensure_default_category()
	
	for cat in data.categories.duplicate():
		if cat.category_name.is_empty():
			continue
		_add_category(cat.category_name)

	if !data.default_category.is_empty():
		for cat in category_container.get_children():
			if cat is GDLLogCategory and cat.category_name == data.default_category and cat.default_btn != null:
				cat.default_btn.button_pressed = true
				break



func _connect_unique(signal_obj: Signal, callback: Callable) -> void:
	if signal_obj.is_connected(callback):
		signal_obj.disconnect(callback)
	signal_obj.connect(callback)



func _add_category(_name: String = ""): ## _name only applicable at loading
	var _n = CATEGORY_SCENE.instantiate() as GDLLogCategory 
	var low_name: String = _name.to_lower() 
	_n.category_name = low_name
	category_container.add_child(_n)
	_n.data = data
	for c: GDLCategoryData in data.categories:
		if c.category_name == _name:
			_n.cat_data = c
			break
	_n._data_ready()
	
	_n.log_category_changed.connect(func() -> void: request_categories_save.emit()) 
	_n.set_default_category.connect(_on_set_default_category)
	_n.move_category_requested.connect(_on_category_move_requested)
	_n.show_delete_category_prompt.connect(_on_show_delete_category_prompt)
	_n.select_btn.toggled.connect(
		func(toggle_on) -> void: 
			if toggle_on: 
				current_category = _n.category_name
				for c: GDLLogCategory in category_container.get_children():
					if c.category_name != current_category:
						c.select_btn.button_pressed = false
						c.select_btn.disabled = false
	)
	_n.tree_exited.connect(_on_category_tree_exited)
	handle_category_mov_button_state()
	
	if !low_name.is_empty():
		_n.default_btn.button_pressed = data.default_category == low_name
	else:
		_n.is_new = true
		_n.line_edit.grab_focus()
		await get_tree().physics_frame
		await get_tree().physics_frame
		category_scroll_container.get_h_scroll_bar().value = category_scroll_container.	get_h_scroll_bar().max_value
	



func ensure_default_category() -> void:
	var c_names := []
	for c in data.categories:
		c_names.append(c.category_name)
	if c_names.is_empty() and data.default_category != "" or !c_names.has(data.default_category):
		data.default_category = ""



func _on_category_move_requested(category: GDLLogCategory, direction: int) -> void:
	var cats: Array = category_container.get_children()
	var from: int = category.get_index()
	var to: int = from + direction

	if to < 0 or to >= cats.size():
		return

	for c in cats:
		c.move_left_btn.disabled = true
		c.move_right_btn.disabled = true
		c.move_left_btn.add_theme_color_override("icon_disabled_color", c.move_left_btn.get_theme_color("icon_normal_color"))
		c.move_right_btn.add_theme_color_override("icon_disabled_color", c.move_right_btn.get_theme_color("icon_normal_color"))
	category_container.get_child(0).move_left_btn.add_theme_color_override("icon_disabled_color", Color.TRANSPARENT)
	category_container.get_child(category_container.get_child_count() - 1).move_right_btn.add_theme_color_override("icon_disabled_color", Color.TRANSPARENT)

	var h_sep: float = float(category_container.get_theme_constant("h_separation"))
	var other: GDLLogCategory = cats[to]

	var category_delta := Vector2(direction * (other.size.x + h_sep), 0.0)
	var other_delta := Vector2(-direction * (category.size.x + h_sep), 0.0)

	var tween := create_tween().set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CUBIC).set_parallel()
	category.offset_transform_enabled = true
	other.offset_transform_enabled = true

	tween.tween_property(category, "offset_transform_position", category_delta, 0.05)
	tween.tween_property(other, "offset_transform_position", other_delta, 0.05)
	await tween.finished 

	category_container.move_child(category, to)
	category.offset_transform_position = Vector2.ZERO
	category.offset_transform_enabled = false
	other.offset_transform_position = Vector2.ZERO
	other.offset_transform_enabled = false
	request_categories_save.emit()
	for c in cats:
		c.move_left_btn.disabled = false
		c.move_right_btn.disabled = false
		c.move_left_btn.add_theme_color_override("icon_disabled_color", Color.TRANSPARENT)
		c.move_right_btn.add_theme_color_override("icon_disabled_color", Color.TRANSPARENT)
	category_container.get_child(0).move_left_btn.disabled = true
	category_container.get_child(category_container.get_child_count() - 1).move_right_btn.disabled = true



func _on_category_tree_exited() -> void: 
	if is_shutting_down:
		return

	handle_category_mov_button_state()
	request_categories_save.emit()



func _on_set_default_category(cat: GDLLogCategory, set_status: bool) -> void:
	if _default_setting_in_progress:
		return
		
	var new_default: String = cat.category_name if set_status else ""
	var changed: bool = data.default_category != new_default
	data.default_category = new_default
	_default_setting_in_progress = true
	
	for log_c in category_container.get_children():
		if log_c is GDLLogCategory and log_c.default_btn != null:
			if log_c != cat:
				log_c.default_btn.button_pressed = false

	if set_status and cat.default_btn != null:
		cat.default_btn.button_pressed = true
	
	data.default_category = cat.category_name if set_status else "" 
	_default_setting_in_progress = false

	if changed:
		request_categories_save.emit()
	



func handle_category_mov_button_state() -> void:
	for i in range(category_container.get_child_count()):
		var category = category_container.get_child(i)
		category.move_left_btn.disabled = (i == 0)
		category.move_right_btn.disabled = (i == category_container.get_child_count() - 1)

#endregion



#region Log Files

func load_log_files(is_initializing: bool = false) -> void: ## Used to both initialize and reload the file list
		if not is_active or is_reloading:
			return 

		if data != null:
			base_dir = data.base_dir

		if base_dir == "":
			printerr("GDLogger: Failed to load Base Directory!")
			return

		if current_category == "" and !data.categories.is_empty() and data.categories[0] != null:
			for cat in data.categories:
				if cat.category_name == data.default_category:
					current_category = cat.category_name
					for log_cat in category_container.get_children():
						if log_cat.category_name == current_category:
							log_cat.select_btn.button_pressed = true
					break

		if current_category == "":
			_clear_all_log_files()
			return

		var target_files: Array = _sort_file_list(current_category)

		var current_file_names: Array = []
		for lf in log_files:
			if is_instance_valid(lf):
				current_file_names.append(lf.file_name)

		if !is_initializing and current_file_names == target_files:
			return

		is_reloading = true
		_reconcile_log_files(target_files, current_category)
		_apply_logfile_colors()
		is_reloading = false



func _clear_all_log_files() -> void:
		for child in file_container.get_children():
				file_container.remove_child(child)
				child.queue_free()
		log_files.clear()



func _reconcile_log_files(target_files: Array, category_name: String) -> void:
	var existing_by_name: Dictionary = {}
	for lf in log_files:
		if is_instance_valid(lf):
			existing_by_name[lf.file_name] = lf

	var target_set: Dictionary = {}
	for file_name in target_files:
		target_set[file_name] = true

	for file_name in existing_by_name.keys():
		if not target_set.has(file_name):
			var lf: GDLLogFile = existing_by_name[file_name]
			if is_instance_valid(lf):
				file_container.remove_child(lf)
				lf.queue_free()
			existing_by_name.erase(file_name)

	var updated_log_files: Array[GDLLogFile] = []

	for i in range(target_files.size()):
		var file_name: String = str(target_files[i])
		var lf: GDLLogFile = null

		if existing_by_name.has(file_name):
			lf = existing_by_name[file_name]
			if lf.get_index() != i:
				file_container.move_child(lf, i)
		else:
			lf = _create_logfile_obj(category_name, file_name)
			if lf == null:
				continue
			file_container.add_child(lf)
			file_container.move_child(lf, i)
			lf.button_up.connect(_open_log_file.bind(lf))

		updated_log_files.append(lf)

	log_files = updated_log_files



func _create_logfile_obj(category_name: String, file_name: String) -> GDLLogFile:
		var file_path: String = str(base_dir.path_join(str(category_name, "_logs")).path_join(file_name), "/")
		
		if not FileAccess.file_exists(file_path):
			return null

		var f := FileAccess.open(file_path, FileAccess.READ)
		if f == null:
			return null
				
		var content := f.get_file_as_string(file_path)
		var has_error := f.get_open_error() != OK
		f.close()
				
		var lf: GDLLogFile = LOG_FILE_BUTTON.instantiate() as GDLLogFile
		lf.category_name = category_name
		lf.file_name = file_name
		lf.file_path = file_path
		lf.file_contents = content
		lf.mouse_entered.connect(func() -> void: hovered_logfile = lf)
		lf.mouse_exited.connect(func() -> void: hovered_logfile = null)
		lf.connect_to_popup(popup_panel)

		if hovered_logfile != null and hovered_logfile.file_name == file_name and hovered_logfile.category_name == category_name:
			lf.mouse_entered.emit()

		if has_error or !lf.is_file_valid():
			lf.assign_icon(false)

		return lf


func _get_category_files(category_name: String) -> PackedStringArray:
		if base_dir == "" or category_name.is_empty():
			return []

		var c_path: String = str(base_dir.path_join(category_name), "_logs/")
		var d := DirAccess.open(c_path)
		if d != null:
			return d.get_files()

		return []




func _sort_file_list(category_name: String) -> Array:
	var file_list: PackedStringArray = _get_category_files(category_name) 
	var fin_list: Array = [] 
	
	if cur_sort in [0, 1]:
		var stray_files: PackedStringArray = []
		for file in file_list:
			if !file.ends_with(".log") or file.is_empty():
				continue

			if file.begins_with(category_name):
				fin_list.append(file)
			else:
				stray_files.append(file)

		if cur_sort == 0: # NEW
			fin_list.reverse()
	
		if !stray_files.is_empty():
			for file in stray_files:
				fin_list.append(file)

	return fin_list



func _open_log_file(log_file: GDLLogFile) -> void:
	if !log_file.file_name.ends_with(".log"):
		return
	
	if open_log_with_os:
		var abs_path = ProjectSettings.globalize_path(log_file.file_path)
		OS.shell_open(abs_path)
		return

	popup_panel.content = log_file.file_contents
	popup_panel.popup()
	
	var fin_time: String = ""
	var fin_date: String = ""
	if log_file.is_gdl_name(log_file.file_name):
		var _timestamp: String = log_file.file_name.lstrip(str(log_file.category_name, "(")).rstrip(").log")
		var _splits: Array = _timestamp.split("_") 
		var _m: Array[String] = [
			"N/A",
			" Jan ",
			" Feb ",
			" March ",
			" April ",
			" May ",
			" June ",
			" July ",
			" Aug ",
			" Sep ",
			" Oct ",
			" Nov ",
			" Dec "
		]

		fin_time = str(
			_splits[1].substr(0, 2), ":", 
			_splits[1].substr(2, 2), ":", 
			_splits[1].substr(4, 2)	
		)
		
		fin_date = str(
			_splits[0].substr(4, 2),
			_m[int(_splits[0].substr(2, 2))],
			str(20, (_splits[0].substr(0, 2)))
		)
	
	popup_panel.file_name = str(fin_date, " | ", fin_time)



func _on_colorcode_changed(toggled_on: bool) -> void:
	data.colorcode_dates = toggled_on
	_apply_logfile_colors()



func _apply_logfile_colors() -> void:
	var group := -1
	var color := Color.WHITE
	var prev_date := ""

	for file: GDLLogFile in file_container.get_children():
		if not data.colorcode_dates:
			_clear_logfile_color(file)
			continue

		if group < 0 or not file.date_stamp.contains(prev_date):
			group += 1
			color = _get_group_color(group)

		_set_logfile_color(file, color)
		prev_date = file.date_stamp



func _get_group_color(group: int) -> Color:
	var is_dark: bool = settings.get_setting("interface/theme/base_color").get_luminance() <= 0.5
	var saturation := 0.75 if is_dark else 0.9
	var value := 0.95 if is_dark else 0.55
	return Color.from_hsv(fmod(group * HUE_STEP, 1.0), saturation, value)



func _set_logfile_color(file: GDLLogFile, color: Color) -> void:
	file.add_theme_color_override("font_color", color)
	file.add_theme_color_override("font_hover_color", color.lightened(0.2))
	file.add_theme_color_override("font_hover_pressed_color", color.darkened(0.2))



func _clear_logfile_color(file: GDLLogFile) -> void:
	for item in LOGFILE_COLOR_ITEMS:
		file.remove_theme_color_override(item)



func _on_log_settings_button_up() -> void:
	log_settings_popup.visible = !log_settings_popup.visible
	log_settings_popup.size = Vector2.ZERO
	log_settings_popup.initial_position = Window.WINDOW_INITIAL_POSITION_ABSOLUTE
	log_settings_popup.position = Vector2i(log_settings_btn.get_screen_position() + Vector2(48, -218))

	if log_settings_popup.visible:
		log_settings_popup.popup()



func _on_show_delete_category_prompt(category: GDLLogCategory) -> void:
	prompt_popup.show()
	reload_dock_btn.hide()
	del_cat_popup.show()
	category_to_delete = category



func _on_del_prompt_button_up(btn: Button) -> void:
	var cat_path: String = str(data.base_dir, category_to_delete.category_name, "_logs") if category_to_delete else ""

	match btn:
		
		cancel_del_cat_btn:
			category_to_delete = null
		
		keep_dir_yes_btn:
			category_to_delete.queue_free()
		
		keep_dir_no_btn:
			var abs_path: String = ProjectSettings.globalize_path(cat_path)
			if DirAccess.dir_exists_absolute(abs_path) and OS.move_to_trash(abs_path) != OK:
				printerr("GDLogger: Failed to delete directories & files upon request. Please delete manually if desired.")
			if data.default_category == category_to_delete.category_name: 
				data.default_category = ""
			
			category_to_delete.queue_free()
			
	prompt_popup.hide()
	del_cat_popup.hide()
	reload_dock_btn.hide()

#endregion
