@tool
extends Control

signal request_save(ignore_errors:bool, source: String) ## Emitted to dock.gd to save dock's categories state to file. Settings still handles on a per case basis. "source" is used to specify what action emitted the signal for debugging purposes.

@onready var base_dir_line: LineEdit = %BaseDirLineEdit
@onready var base_dir_apply_btn: Button = %BaseDirApplyButton
@onready var base_dir_revert_btn: Button = %BaseDirRevertButton

@onready var header_line: LineEdit = %HeaderLineEdit
@onready var header_apply_btn: Button = %HeaderApplyButton
@onready var header_revert_btn: Button = %HeaderRevertButton

@onready var entry_format_line: LineEdit = %EntryFormatLineEdit
@onready var entry_format_apply_btn: Button = %EntryFormatApplyButton
@onready var entry_format_revert_btn: Button = %EntryFormatRevertButton
@onready var entry_format_warning: Panel = %EntryFormatWarning

@onready var autostart_btn: CheckButton = %AutostartCheckButton
@onready var utc_btn: CheckButton = %UTCCheckButton

@onready var limits_tabbar: TabBar = %LimitsTabBar

@onready var entry_count_container: PanelContainer = %EntryCount
@onready var entry_count_action_btn: OptionButton = %EntryActionOptButton
@onready var entry_count_spinbox: SpinBox = %EntryCountSpinBox
var entry_count_spinbox_line: LineEdit

@onready var session_timer_container: PanelContainer= %SessionTimer
@onready var session_timer_action_btn: OptionButton = %SessionTimerActionOptButton
@onready var session_duration_spinbox: SpinBox = %SessionDurationSpinBox
var session_duration_spinbox_line: LineEdit

var file_count_spinbox_line: LineEdit
@onready var file_count_spinbox: SpinBox = %FileCountSpinBox

@onready var id_fold_cont: FoldableContainer = %IDFoldableContainer
@onready var id_align_opt_btn: OptionButton = %IDAlignOptButton

@onready var id_toggle_btn: CheckButton = %IDToggleShowCheckButton
@onready var id_startup_btn: CheckButton = %IDStartupCheckButton
@onready var id_print_btn: CheckButton = %IDPrintCheckButton

@onready var id_font_sett_cont: FoldableContainer = %IDFontFoldableContainer
var id_inspector: EditorInspector

@onready var hotkey_container: FoldableContainer = %HotkeyFoldableContainer
var inspector: EditorInspector

@onready var general_fold_cont: FoldableContainer = %GeneralFoldableContainer
@onready var dir_fold_cont: FoldableContainer = %DirectoryFoldableContainer

@export var data: GDLData = null

var id_font_settings_min_size: int = 200

var btn_array: Array[Control] = []


## Index 3 is a SEPERATOR and should not be used.
enum LimitMethod {
	ENTRY_COUNT,
	SESSION_TIMER,
	BOTH
}



func _ready() -> void:
	inspector = _create_editor_inspector(hotkey_container)
	inspector.edit(ResourceLoader.load("uid://dyi2aml73k4g8"))
	id_inspector = _create_editor_inspector(id_font_sett_cont)
	id_inspector.edit(ResourceLoader.load("uid://dskegm87ypj8f"))
	id_font_sett_cont.folding_changed.connect(_handle_fold_container_min_size.bind(id_font_sett_cont))
	hotkey_container.folding_changed.connect(_handle_fold_container_min_size.bind(hotkey_container))
	_assign_spinbox_line_edits()
	_connect_spinbox_line_submitted()

	limits_tabbar.tab_changed.connect(_handle_limit_method_visibility)
	session_duration_spinbox.get_line_edit().theme_type_variation = "LineEdit_LimitsSpinbox"
	entry_count_spinbox.get_line_edit().theme_type_variation = "LineEdit_LimitsSpinbox"
	file_count_spinbox.get_line_edit().theme_type_variation = "LineEdit_LimitsSpinbox"

	btn_array = [
		base_dir_line,
		base_dir_apply_btn,
		base_dir_revert_btn, 
		header_line,
		header_apply_btn,
		header_revert_btn,
		entry_format_line,
		entry_format_apply_btn,
		entry_format_revert_btn,
		autostart_btn,
		utc_btn,
		id_print_btn,
		id_toggle_btn,
		id_align_opt_btn,
		id_startup_btn,
		entry_count_action_btn,
		session_timer_action_btn,
		file_count_spinbox,
		file_count_spinbox_line,
		entry_count_spinbox,
		entry_count_spinbox_line,
		session_duration_spinbox,
		session_duration_spinbox_line
	]


	for node in btn_array:
		_connect_control_signal(node)



## Called by dock.gd after data is initialized.
func initialize_tab() -> void:
	entry_format_warning.visible = !_entry_format_has_tag(entry_format_line.text)
	data.apply_values()
	_handle_limit_method_visibility(data.limit_method)
	


# Called by dock.gd
func init_visibility() -> void:
	base_dir_revert_btn.disabled = true
	header_revert_btn.disabled = true
	entry_format_revert_btn.disabled = true
	
	var fold_conts: Array[FoldableContainer] = [
		general_fold_cont,
		id_fold_cont,
		dir_fold_cont,
		hotkey_container
	]

	for container in fold_conts:
		container.folded = true 



func _create_editor_inspector(parent: Control) -> EditorInspector:
	var new_inspector := EditorInspector.new()
	parent.add_child(new_inspector)
	new_inspector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	new_inspector.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return new_inspector



func _connect_unique(signal_obj: Signal, callback: Callable) -> void:
	if signal_obj.is_connected(callback):
		signal_obj.disconnect(callback)
	signal_obj.connect(callback)



func _assign_spinbox_line_edits() -> void:
	file_count_spinbox_line = file_count_spinbox.get_line_edit()
	entry_count_spinbox_line = entry_count_spinbox.get_line_edit()
	session_duration_spinbox_line = session_duration_spinbox.get_line_edit() 



func _connect_spinbox_line_submitted() -> void:
	var line_edits: Array[LineEdit] = [
		file_count_spinbox_line,
		entry_count_spinbox_line,
		session_duration_spinbox_line 
	]

	for line_edit in line_edits:
		_connect_unique(line_edit.text_submitted, _on_spinbox_line_edit_submitted.bind(line_edit))



func _connect_control_signal(node: Control) -> void:
	if node is CheckButton:
		_connect_unique(node.toggled, _on_checkbox_toggled.bind(node))
	elif node is OptionButton:
		_connect_unique(node.item_selected, _on_optbtn_item_selected.bind(node))
	elif node is LineEdit:
		_connect_unique(node.text_changed, _on_line_edit_text_changed.bind(node))
		_connect_unique(node.text_submitted, _on_line_edit_text_submitted.bind(node))
	elif node is SpinBox:
		_connect_unique(node.value_changed, _on_spinbox_value_changed.bind(node)) 
	elif node is Button:
		_connect_unique(node.pressed, _on_button_pressed.bind(node))




#region Local Functions

func _apply_new_base_directory() -> bool: 
	var old_dir = data.base_dir
	var new_dir = base_dir_line.text.strip_edges()
 
	if new_dir == "":
		push_warning("GDLogger: Base directory cannot be empty. Reverting to previous path[", old_dir, "].")
		base_dir_line.text = old_dir
		return false


	if not new_dir.ends_with("/"):
		new_dir += "/"


	var d = DirAccess.open(new_dir) 
	if d == null or DirAccess.get_open_error() != OK:
		var res : int = OK

		var create_path = new_dir
		if new_dir.begins_with("user://") or new_dir.begins_with("res://"):
			create_path = ProjectSettings.globalize_path(new_dir)

		res = DirAccess.make_dir_absolute(create_path)
		if res != OK:
			push_warning("GDLogger: Failed to create directory using path[", new_dir, "]. Reverting back to previous directory path[", old_dir, "].")
			base_dir_line.text = old_dir 
			return false

		d = DirAccess.open(new_dir)

	data.base_dir = new_dir
	base_dir_line.text = new_dir
	base_dir_revert_btn.tooltip_text = str("Revert to:  ", new_dir)
 
	return true



func _handle_limit_method_visibility(to: int) -> void:
	data.limit_method = to
	if limits_tabbar.get_current_tab() != to: limits_tabbar.set_current_tab(to)
	entry_count_container.visible = to in [LimitMethod.ENTRY_COUNT, LimitMethod.BOTH]
	session_timer_container.visible = to in [LimitMethod.SESSION_TIMER, LimitMethod.BOTH]




func _handle_fold_container_min_size(is_folded: bool, fold_container: FoldableContainer) -> void:
	match fold_container:
		id_font_sett_cont:
			id_fold_cont.size_flags_vertical = Control.SIZE_SHRINK_BEGIN if is_folded else Control.SIZE_EXPAND_FILL
			id_font_sett_cont.size_flags_vertical = Control.SIZE_SHRINK_BEGIN if is_folded else Control.SIZE_EXPAND_FILL 
			id_font_sett_cont.custom_minimum_size.y = id_font_settings_min_size if !is_folded else 0
		hotkey_container:
			id_fold_cont.size_flags_vertical = Control.SIZE_SHRINK_BEGIN if is_folded else Control.SIZE_EXPAND_FILL
			hotkey_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN if is_folded else Control.SIZE_EXPAND_FILL 
			hotkey_container.custom_minimum_size.y = id_font_settings_min_size if !is_folded else 0

#endregion




#region Helpers


func _entry_format_has_tag(format: String) -> bool: ## Returns true if {entry} tag is present or is NOT empty.
	if format.is_empty(): return false
	return format.contains("{entry}")

#endregion




#region Signal receivers

func _on_button_pressed(node: Button) -> void:
	match node:
		base_dir_apply_btn:
			if _apply_new_base_directory():
				base_dir_revert_btn.disabled = true
				base_dir_apply_btn.disabled = true
				request_save.emit(false, "dock_settings.gd - base_dir_apply_btn")
		
		base_dir_revert_btn:
			base_dir_line.text = data.base_dir
			base_dir_apply_btn.disabled = true
			base_dir_revert_btn.disabled = true

		header_apply_btn:
			data.header_format = header_line.text
			header_line.release_focus()
			header_revert_btn.disabled = true
			header_apply_btn.disabled = true
			request_save.emit(false, "dock_settings.gd - header_apply_btn")
		
		header_revert_btn:
			header_line.text = data.header_format
			header_apply_btn.disabled = true
			header_revert_btn.disabled = true

		entry_format_apply_btn:
			data.entry_format = entry_format_line.text
			entry_format_line.release_focus() 
			entry_format_apply_btn.disabled = true
			entry_format_revert_btn.disabled = true
			request_save.emit(false, "dock_settings.gd - entry_format_apply_btn")

		entry_format_revert_btn:
			entry_format_line.text = data.entry_format
			entry_format_apply_btn.disabled = true
			entry_format_revert_btn.disabled = true




func _on_line_edit_text_changed(new_text: String, node: LineEdit) -> void:
	base_dir_apply_btn.disabled = base_dir_line.text == data.base_dir if !base_dir_line.text.is_empty() else true
	base_dir_revert_btn.disabled = base_dir_line.text == data.base_dir if !base_dir_line.text.is_empty() else true
	header_apply_btn.disabled = header_line.text == data.header_format if !header_line.text.is_empty() else true
	header_revert_btn.disabled = header_line.text == data.header_format if !header_line.text.is_empty() else true
	entry_format_apply_btn.disabled = entry_format_line.text == data.entry_format if !entry_format_line.text.is_empty() else true
	entry_format_revert_btn.disabled = entry_format_line.text == data.entry_format if !entry_format_line.text.is_empty() else true

	match node:
		base_dir_line:
			base_dir_revert_btn.tooltip_text = str("Revert to:   ", data.base_dir)
		header_line:
			header_revert_btn.tooltip_text = str("Revert to:   ", data.header_format)
		entry_format_line: 			
			entry_format_warning.visible = !_entry_format_has_tag(new_text)
			entry_format_line.tooltip_text = str("Revert to:   ", data.entry_format)
			entry_format_line.set_theme_type_variation("LineEdit_FormatFields" if _entry_format_has_tag(new_text) else "LineEdit_FormatFieldsInvalid")
			


func _on_line_edit_text_submitted(new_text: String, node: LineEdit) -> void:
	if new_text.is_empty():
		return
	
	match node:
		base_dir_line:
			if _apply_new_base_directory():
				base_dir_line.release_focus()
				data.base_dir = base_dir_line.text
				base_dir_revert_btn.disabled = true

		header_line:
			header_line.release_focus()
			data.header_format = header_line.text
			header_revert_btn.disabled = true

		entry_format_line:
			entry_format_line.release_focus()
			data.entry_format = entry_format_line.text
			entry_format_revert_btn.disabled = true

	base_dir_apply_btn.disabled = base_dir_line.text == data.base_dir if !base_dir_line.text.is_empty() else true
	header_apply_btn.disabled = header_line.text == data.header_format if !header_line.text.is_empty() else true
	entry_format_apply_btn.disabled = entry_format_line.text == data.entry_format if !entry_format_line.text.is_empty() else true
	request_save.emit(false, "dock_settings.gd - _on_line_edit_text_submitted")



func _on_optbtn_item_selected(index: int, node: OptionButton) -> void:
	match node:
		entry_count_action_btn:
			data.entry_count_action = index

		session_timer_action_btn:
			data.session_timer_action = index

		id_align_opt_btn:
			data.id_align = index

	request_save.emit(false, "dock_settings.gd - _on_optbtn_item_selected")



func _on_checkbox_toggled(toggled_on: bool, node: CheckButton) -> void:
	match node:
		autostart_btn:
			data.autostart = toggled_on

		utc_btn:
			data.utc = toggled_on

		id_print_btn:
			data.id_print = toggled_on

		id_toggle_btn:
			data.id_toggle = toggled_on

		id_startup_btn:
			data.id_startup = toggled_on

	request_save.emit(false, "dock_settings.gd - _on_checkbox_toggled")







func _on_spinbox_line_edit_submitted(new_text: String, node: Control) -> void:
	match node:
		file_count_spinbox_line:
			data.file_cap = int(new_text)
			file_count_spinbox_line.release_focus()
			file_count_spinbox.release_focus() 

		entry_count_spinbox_line:
			data.entry_cap = int(new_text)
			entry_count_spinbox.release_focus()
			entry_count_spinbox_line.release_focus() 

		session_duration_spinbox_line:
			data.session_duration = int(new_text)
			session_duration_spinbox.release_focus()
			session_duration_spinbox_line.release_focus() 

	request_save.emit(false, "dock_settings.gd - _on_spinbox_line_edit_submitted")



func _on_spinbox_value_changed(value: float, node: SpinBox) -> void:
	var u_line = node.get_line_edit()
	u_line.set_caret_column(u_line.text.length())
	if u_line.get_caret_column() == u_line.text.length() - 1:
		u_line.set_caret_column(u_line.text.length())
	else: u_line.set_caret_column(u_line.get_caret_column() + 1)

	match node:
		file_count_spinbox:
			data.file_cap = int(value)
			
		entry_count_spinbox:
			data.entry_cap = int(value)

		session_duration_spinbox:
			data.session_duration = int(value)

	request_save.emit(false, "dock_settings.gd - _on_spinbox_value_changed")

#endregion










