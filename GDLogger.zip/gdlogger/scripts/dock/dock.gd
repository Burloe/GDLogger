@tool
class_name GDLDock extends EditorDock


const THEME_DEBOUNCE_SEC: float = 0.08
const gdl_theme = preload("uid://gjcp57h03j4p")
const gh_ico_darkmode = preload("uid://c74n2f1j4wew5")
const gh_ico_lightmode = preload("uid://c0fie23lxf1be")
const DATA_PATH: String = "res://addons/gdlogger/data.tres"
const COLOR_TO_STYLEBOX := {
	"TabContainer": {
		"font_selected_color": "tab_selected",
		"font_hovered_color": "tab_hovered",
		"font_unselected_color": "tab_unselected",
		"font_disabled_color": "tab_disabled",
	},
	"FoldableContainer": {
		"collapsed_font_color": "title_collapsed_panel",
		"hover_font_color": "title_collapsed_hover_panel",
	}
}
const BUTTON_STATES := ["normal", "hover", "pressed", "hover_pressed", "disabled"]
const TAB_CONTAINER_RULES := {
	"base_col-1": ["panel"],
	"accent_col": ["tab_selected"],
}
const STYLEBOX_COLORS := {
	"Button_Accented": {
		"accent_col": ["normal"],
		"accent_col+1": ["hover"],
		"accent_col-1": ["pressed", "hover_pressed"],
	},
	"Button_CategoryLoad": {"accent_col": ["hover", "pressed", "hover_pressed", "disabled"]},
	"Button_CategoryRevertButton": {"base_col-1": BUTTON_STATES},
	"Button_SortButton": {"base_col-2": BUTTON_STATES},
	"LogFile": {"base_col+1": ["hover"], "base_col-1": ["pressed", "hover_pressed"]},
	"LineEdit": {"base_col-1": ["*"]},
	"LineEdit_CategoryFieldValid": {"base_col-1": ["*"]},
	"LineEdit_CategoryFieldInvalid": {"base_col-1": ["*"]},
	"HScrollBar": {"base_col+1": ["grabber_highlight"], "base_col-1": ["grabber_pressed"]},
	"VScrollBar": {"base_col+1": ["grabber_highlight"], "base_col-1": ["grabber_pressed"]},
	"OptionButton": {"base_col-1": ["normal", "hover"], "base_col-2": ["pressed", "hover_pressed"]},
	"Panel": {"base_col-2": ["*"]},
	"Panel_BaseCol_NoCMarg": {"base_col-2": ["*"]},
	"PopupMenu": {"base_col+2": ["hover", "separator"], "base_col-2": ["panel"]},
	"PanelContainer_CategoryToolbar": {"base_col-1": ["panel"]},
	"PanelContainer_TabBar": {"base_col-2": ["panel"]},
	"ScrollContainer": {"base_col-1": ["*"]},
	"ScrollContainer_HCMargsOnly": {"base_col-1": ["*"]},
	"ScrollContainer_NoCMargs": {"base_col-1": ["*"]},
	"SpinBox": {"base_col-1": [
		"down_background", "down_background_hover", "down_background_pressed",
		"up_background", "up_background_hover", "up_background_pressed",
	]},
	"TabBar": {"base_col-1": ["tab_hovered"]},
	"TabContainer": TAB_CONTAINER_RULES,
	"TabContainer_NoHCMargs": TAB_CONTAINER_RULES,
	"HSeparator": {"base_col+2": ["separator"]},
	"VSeparator": {"base_col+2": ["separator"]},
	"HSeparator_Weak": {"base_col+1": ["separator"]},
	"VSeparator_Weak": {"base_col+1": ["separator"]},
}
const BORDER_COLORS := {
	"LogFile": {"accent_col": ["hover"], "accent_col-1": ["pressed", "hover_pressed"]},
}

const SPECIAL_COLORS := {
	"Button_RevertButton": {"icon_disabled_color": "disabled"},
	"FoldableContainer": {
		"collapsed_font_color": "title_collapsed_panel",
		"hover_font_color": "title_collapsed_hover_panel",
	},
	"LineEdit_CategoryFieldValid": {"caret_color": "focus"},
	"OptionButton": {
		"hover_font_color": "hover",
		"pressed_font_color": "pressed",
		"icon_hover_color": "hover",
		"icon_pressed_color": "pressed",
		"icon_hover_pressed_color": "hover_pressed",
	},
	"SpinBox": {
		"down_icon_modulate": "down_background",
		"down_hover_icon_modulate": "down_background",
		"down_pressed_icon_modulate": "down_background",
		"up_icon_modulate": "up_background",
		"up_hover_icon_modulate": "down_background",
		"up_pressed_icon_modulate": "down_background",
	},
}

@export var data: GDLData = null
@onready var renable_btn: Button = %RENABLEButton
@onready var docktab_container: TabContainer = %DockTabContainer
@onready var prompt_popup: PanelContainer = %PromptPopupPanelContainer
@onready var delete_category_popup: MarginContainer = %DeleteCategoryPopup
@onready var dock_reload_btn: Button = %ReloadDockButton
@onready var polling_timer: Timer = %PollingTimer
@onready var debounce_timer: Timer = %DebounceTimer

# Logs tab
@onready var logs_tab: HBoxContainer = %LogsTab
@onready var category_container: GridContainer = %CategoryGridContainer 
@onready var lg_open_dir_btn: Button = %LBOpenDirButton
@onready var lg_sort_btn: Button = %LGSortButton
@onready var lg_colorcode_btn: Button = %LGColorCodeCheckButton
@onready var lg_open_with_os_btn: Button = %LGOpenLogsCheckButton
@onready var lg_auto_reload_btn: CheckButton = %LGAutoReloadCheckButton
@onready var lg_poll_rate_slider:HSlider = %PollRateHSlider

# Settings tab
@onready var settings_tab: Control = %SettingsTab
@onready var sett_reset_btn: Button = %ResetSettingsButton
@onready var sett_base_dir_line: LineEdit = %BaseDirLineEdit
@onready var sett_base_dir_apply_btn: Button = %BaseDirApplyButton
@onready var sett_base_dir_revert_btn: Button = %BaseDirRevertButton
@onready var sett_open_dir_btn: Button = %OpenDirButton

@onready var sett_log_header_line: LineEdit = %HeaderLineEdit
@onready var sett_log_header_apply_btn: Button = %HeaderApplyButton
@onready var sett_log_header_revert_btn: Button = %HeaderRevertButton

@onready var sett_entry_format_line: LineEdit = %EntryFormatLineEdit
@onready var sett_entry_format_apply_btn: Button = %EntryFormatApplyButton
@onready var sett_entry_format_revert_btn: Button = %EntryFormatRevertButton
@onready var sett_entry_format_warning: Panel = %EntryFormatWarning

@onready var sett_autostart_btn: CheckButton = %AutostartCheckButton
@onready var sett_utc_btn: CheckButton = %UTCCheckButton

@onready var sett_limit_method_tabbar: TabBar = %LimitsTabBar

@onready var sett_entry_count: PanelContainer = %EntryCount
@onready var sett_entry_count_action_btn: OptionButton = %EntryActionOptButton
@onready var sett_entry_count_action_lbl: Label = %EntryActionLabel
@onready var sett_entry_count_spinbox: SpinBox = %EntryCountSpinBox

@onready var sett_session_timer: PanelContainer = %SessionTimer
@onready var sett_session_timer_action_btn: OptionButton = %SessionTimerActionOptButton
@onready var sett_session_timer_action_lbl: Label = %SessionTimerActionLabel
@onready var sett_session_duration_spinbox: SpinBox = %SessionDurationSpinBox

@onready var sett_file_count_spinbox: SpinBox = %FileCountSpinBox
@onready var sett_id_align_opt_btn: OptionButton = %IDAlignOptButton

@onready var sett_id_toggle_btn: CheckButton = %IDToggleShowCheckButton
@onready var sett_id_startup_btn: CheckButton = %IDStartupCheckButton
@onready var sett_id_print_btn: CheckButton = %IDPrintCheckButton

@onready var data_inspector: EditorInspector = %SaveDataEditorInspector

@onready var version_container: HBoxContainer = %VersionHBoxContainer
@onready var version_linkbtn: LinkButton = %VersionLinkButton

@onready var general_fold_cont: 	FoldableContainer = %GeneralFoldableContainer
@onready var dir_fold_cont: 			FoldableContainer = %DirectoryFoldableContainer

# Help tab
@onready var help_tab: 						TabContainer = 			%HelpTab
@onready var help_setup: 					FoldableContainer = %SetupHelp
@onready var help_categories: 		FoldableContainer = %CategoriesHelp
@onready var help_messages: 			FoldableContainer = %MessagesHelp
@onready var help_concurrency: 		FoldableContainer = %ConcurrencyHelp
@onready var help_functions: 			FoldableContainer = %FunctionsHelp
@onready var help_hotkeys: 				FoldableContainer = %HotkeysHelp
@onready var help_formatting: 		FoldableContainer = %FormattingHelp
@onready var gh_texrect: TextureRect = %GithubTextureRect

@onready var settings = EditorInterface.get_editor_settings()
var theme_col_base = ProjectSettings.get_setting("interface/theme/base_color")
var theme_col_accent = ProjectSettings.get_setting("interface/theme/accent_color")
var theme_contrast = ProjectSettings.get_setting("interface/theme/contrast") 
var plugin_version: String =  "2.0.0":
	set(value):
		plugin_version = value
		if version_linkbtn:
			version_linkbtn.text = str("v.", value)


var is_shutting_down: bool = false:
	set(value):
		is_shutting_down = value
		logs_tab.is_shutting_down = value

var FONT_DARK := Color.BLACK.lightened(0.15)
var FONT_LIGHT := Color.WHITE.darkened(0.15)




#region Inits and signals

func _ready() -> void:
	if FileAccess.file_exists(DATA_PATH):
		data = load(DATA_PATH)
	else:
		regen_data() 
	
	data_inspector.edit(ResourceLoader.load(DATA_PATH))

	logs_tab.data = data 
	logs_tab.is_active = true
	settings_tab.data = data
	data.update_list()

	opened.connect(_start_polling)
	closed.connect(func() -> void: polling_timer.stop())
	visibility_changed.connect(
		func() -> void:
			if visible: _start_polling()
			else:	polling_timer.stop()
	)
	debounce_timer.wait_time = THEME_DEBOUNCE_SEC
	debounce_timer.timeout.connect(_apply_theme_colors)

	docktab_container.tab_changed.connect(
		func(tab: int) -> void: 
			if tab == 1: # 0 is empty tab for the plugin icon
				logs_tab.is_active = true
				logs_tab.load_log_files()
			else:
				logs_tab.is_active = false
	)
	
	logs_tab.request_categories_save.connect(func() -> void: save_data(false, "categories"))
	settings_tab.request_save.connect(save_data)

	# # Signal connections 
	_connect_unique(settings.settings_changed, _on_editor_settings_changed) 
	_connect_unique(lg_open_dir_btn.button_up, _open_directory)
	_connect_unique(sett_open_dir_btn.button_up, _open_directory)
	_connect_unique(sett_reset_btn.button_up, reset_to_default)

	_apply_theme_colors()

	await get_tree().process_frame

	_assign_settings_controls()
	logs_tab.initialize_tab()
	settings_tab.initialize_tab() 
	logs_tab.load_log_files(true)
	_init_visibility()




func _exit_tree() -> void: 
	is_shutting_down = true


func _init_visibility() -> void:
	docktab_container.set_current_tab(1)
	help_tab.set_current_tab(0) 
	settings_tab.init_visibility()

	prompt_popup.hide()
	dock_reload_btn.hide()
	delete_category_popup.hide()
	version_container.show()

	var fold_conts: Array[FoldableContainer] = [
		help_setup,
		help_categories,
		help_messages,
		help_concurrency,
		help_functions,
		help_hotkeys,
		help_formatting
	]

	for container in fold_conts:
		container.folded = true



func _start_polling() -> void:
	if data and data.auto_reload and polling_timer.is_inside_tree():
		polling_timer.start(data.poll_rate)



func _connect_unique(signal_obj: Signal, callback: Callable) -> void:
	if signal_obj.is_connected(callback):
		signal_obj.disconnect(callback)
	signal_obj.connect(callback)



## Reassigns all references after they're ready
func _assign_settings_controls() -> void:
	data.base_dir_ctrl = sett_base_dir_line
	data.header_format_ctrl = sett_log_header_line
	data.entry_format_ctrl = sett_entry_format_line
	data.browser_sort_ctrl = lg_sort_btn 
	data.color_code_ctrl = lg_colorcode_btn
	data.open_logs_enternally_ctrl = lg_open_with_os_btn
	data.auto_reload_ctrl = lg_auto_reload_btn
	data.poll_rate_ctrl = lg_poll_rate_slider
	data.autostart_ctrl = sett_autostart_btn
	data.utc_ctrl = sett_utc_btn
	data.colorcode_dates_ctrl = lg_colorcode_btn
	data.id_print_ctrl = sett_id_print_btn
	data.id_toggle_ctrl = sett_id_toggle_btn
	data.id_startup_ctrl = sett_id_startup_btn
	data.id_align_ctrl = sett_id_align_opt_btn
	data.limit_method_ctrl = sett_limit_method_tabbar
	data.entry_count_container = sett_entry_count
	data.entry_count_action_ctrl = sett_entry_count_action_btn
	data.entry_count_action_lbl = sett_entry_count_action_lbl
	data.session_timer_container = sett_session_timer
	data.session_timer_action_ctrl = sett_session_timer_action_btn
	data.session_timer_action_lbl = sett_session_timer_action_lbl
	data.file_cap_ctrl = sett_file_count_spinbox
	data.file_cap_ctrl_line = sett_file_count_spinbox.get_line_edit()
	data.entry_cap_ctrl = sett_entry_count_spinbox
	data.entry_cap_ctrl_line = sett_entry_count_spinbox.get_line_edit()
	data.session_duration_ctrl = sett_session_duration_spinbox
	data.session_duration_ctrl_line = sett_session_duration_spinbox.get_line_edit()
	
#endregion



#region Public

func reset_to_default() -> void:
	sett_base_dir_apply_btn.disabled = true
	sett_base_dir_revert_btn.disabled = true
	sett_log_header_apply_btn.disabled = true
	sett_log_header_revert_btn.disabled = true
	sett_entry_format_apply_btn.disabled = true
	sett_entry_format_revert_btn.disabled = true
	sett_entry_format_warning.hide()
	data.reset_to_default()



func regen_data() -> void:
	var new := GDLData.new()
	if ResourceSaver.save(new, DATA_PATH) == OK:
		printerr("GDLogger: No plugin data found at path. Successfully generated a new, please reload dock/plugin.")
		prompt_popup.show()
		dock_reload_btn.show()
		delete_category_popup.hide()
	else:
		printerr("GDLogger: No plugin data found at path '", DATA_PATH, "' and GDLogger wasn't able to generate a new one. Please manually R-Click in directory, Create new > Resource > GDLData > Name 'data.tres' > Restart Godot.")
	
	logs_tab.data = new
	settings_tab.data = new
	data = new



## Saves category state to file. "external_source" is used to debug what func/signal called this from another tab script.
func save_data(ignore_errors: bool = false, external_source: String = "") -> void: 
	if is_shutting_down:
		return
	
	save_categories()
	data.update_list()
	var save_err: int = ResourceSaver.save(data, DATA_PATH)
	if save_err != OK and !ignore_errors:
		push_warning("GDLogger: Failed to save settings resource at '", DATA_PATH, "' [", save_err, "] from ", external_source)
	return 



func save_categories() -> void:
	if is_shutting_down:
		return

	data.categories.clear()
	var cats: Array[GDLCategoryData] = []

	for log_c in category_container.get_children():
		if log_c is not GDLLogCategory or log_c.category_name.is_empty():
			continue

		if log_c.default_btn.button_pressed: 
			data.default_category = log_c.category_name

		var c_data: GDLCategoryData = log_c.cat_data if log_c.cat_data else GDLCategoryData.new()
		c_data.category_name = log_c.category_name 
		log_c.cat_data = c_data
		cats.append(c_data) 
	
	data.categories = cats
	logs_tab.handle_category_mov_button_state()

#endregion


#region Private

## Opens "user://gdlogger/category_name/"
func _open_directory() -> void:
	var abs_path = ProjectSettings.globalize_path(data.base_dir)
	OS.shell_open(abs_path)

#endregion



#region Theme

func _on_editor_settings_changed() -> void:
	var new_base: Color = settings.get_setting("interface/theme/base_color")
	var new_accent: Color = settings.get_setting("interface/theme/accent_color")
	var new_contrast: float = settings.get_setting("interface/theme/contrast")

	# Ignore unrelated editor settings changes and skip no-op reapplies
	if new_base == theme_col_base and new_accent == theme_col_accent and new_contrast == theme_contrast:
		return

	theme_col_base = new_base
	theme_col_accent = new_accent
	theme_contrast = new_contrast
	logs_tab.load_log_files()
	
	if debounce_timer: 
		debounce_timer.start()



func _get_theme_colors() -> Dictionary:
	var contrast: float = settings.get_setting("interface/theme/contrast")
	var base_col: Color = settings.get_setting("interface/theme/base_color")
	var accent_col: Color = settings.get_setting("interface/theme/accent_color")
	var factor: float = 1.25
	var is_dark: bool = base_col.get_luminance() <= 0.5

	var shift := func(c: Color, amount: float) -> Color:
		var go_lighter: bool = is_dark == (amount >= 0.0)
		return c.lightened(absf(amount)) if go_lighter else c.darkened(absf(amount))

	return {
		"is_dark": is_dark,
		"contrast": contrast,
		"base_col+2": shift.call(base_col,  contrast * factor),
		"base_col+1": shift.call(base_col,  contrast),
		"base_col":   base_col,
		"base_col-1": shift.call(base_col, -contrast),
		"base_col-2": shift.call(base_col, -contrast * factor),
		"accent_col+2": shift.call(accent_col,  contrast * factor),
		"accent_col+1": shift.call(accent_col,  contrast),
		"accent_col":   accent_col,
		"accent_col-1": shift.call(accent_col, -contrast),
		"accent_col-2": shift.call(accent_col, -contrast * factor),
	}



func _state_from_name(color_name: String) -> String:
	if color_name.contains("hover_pressed"): return "hover_pressed"
	if color_name.contains("hover"):         return "hover"
	if color_name.contains("pressed"):       return "pressed"
	if color_name.contains("disabled"):      return "disabled"
	return "normal"



func _font_for_bg(bg: Color, state: String, contrast: float) -> Color:
	var bg_is_light: bool = bg.get_luminance() > 0.5
	var col: Color = FONT_DARK if bg_is_light else FONT_LIGHT
	match state:
		"hover", "pressed", "hover_pressed":
			col = col.lightened(contrast) if bg_is_light else col.darkened(contrast)
	return col



func _apply_font_icon_colors(tags: Dictionary) -> void:
	var contrast: float = tags["contrast"]

	for control_type in gdl_theme.get_color_type_list():
		if control_type == "EditorIcons":
			continue

		for color_name in gdl_theme.get_color_list(control_type):
			if not (color_name.begins_with("font_") or color_name.begins_with("icon_")):
				continue
			if color_name.contains("outline") or color_name.contains("shadow"):
				continue

			var sb_name: String = COLOR_TO_STYLEBOX.get(control_type, {}).get(color_name, _state_from_name(color_name))

			var bg: Color = tags["base_col"]
			if gdl_theme.has_stylebox(sb_name, control_type):
				var sb := gdl_theme.get_stylebox(sb_name, control_type)
				if sb is StyleBoxFlat:
					bg = sb.bg_color

			gdl_theme.set_color(color_name, control_type,
				_font_for_bg(bg, _state_from_name(color_name), contrast))

	var base_is_dark: bool = tags["base_col"].get_luminance() < 0.5
	var text_color: Color = FONT_LIGHT if base_is_dark else FONT_DARK

	gh_texrect.texture = gh_ico_darkmode if base_is_dark else gh_ico_lightmode

	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color"]:
		gdl_theme.set_color(c, "CheckButton", text_color)
	gdl_theme.set_color("caret_color", "LineEdit_FormatFields", Color.WHITE if base_is_dark else Color.BLACK)

	for ctrl_type in SPECIAL_COLORS:
		for color_name in SPECIAL_COLORS[ctrl_type]:
			var stylebox_name: String = SPECIAL_COLORS[ctrl_type][color_name]
			var stylebox := gdl_theme.get_stylebox(stylebox_name, ctrl_type) as StyleBoxFlat
			if stylebox == null:
				continue
			gdl_theme.set_color(color_name, ctrl_type, _special_color(color_name, stylebox.bg_color))



func _special_color(color_name: String, bg: Color) -> Color:
	var bg_is_dark := bg.get_luminance() < 0.5

	if color_name.contains("icon"):
		# Priority: disabled beats pressed beats hover.
		if color_name.contains("disabled"):
			return Color("d9d9d932") if bg_is_dark else Color("26262632")
		if color_name.contains("pressed"):
			return Color.WHITE.darkened(0.3) if bg_is_dark else Color.BLACK.darkened(0.05)
		if color_name.contains("hover"):
			return Color.WHITE if bg_is_dark else Color.BLACK.lightened(0.25)

	return FONT_LIGHT if bg_is_dark else FONT_DARK
		


func _apply_theme_colors() -> void:
	var tags: Dictionary = _get_theme_colors()
	gdl_theme.set_block_signals(true)

	for control_type in gdl_theme.get_stylebox_type_list():
		if control_type == "EditorIcons":
			continue

		for stylebox_name in gdl_theme.get_stylebox_list(control_type):
			var sb: StyleBox = gdl_theme.get_stylebox(stylebox_name, control_type)
			var color: Color = tags[_lookup_tag(STYLEBOX_COLORS, control_type, stylebox_name, "base_col")]

			if sb is StyleBoxFlat:
				sb.bg_color = color
				var border_tag := _lookup_tag(BORDER_COLORS, control_type, stylebox_name)
				if not border_tag.is_empty():
					sb.border_color = tags[border_tag]
			elif sb is StyleBoxLine:
				sb.color = color

	_apply_font_icon_colors(tags)

	gdl_theme.set_block_signals(false)
	gdl_theme.emit_changed()



func _lookup_tag(rules: Dictionary, control_type: String, stylebox_name: String, fallback: String = "") -> String:
	var type_rules: Dictionary = rules.get(control_type, {})
	for tag in type_rules:
		if stylebox_name in type_rules[tag] or "*" in type_rules[tag]:
			return tag
	return fallback

#endregion